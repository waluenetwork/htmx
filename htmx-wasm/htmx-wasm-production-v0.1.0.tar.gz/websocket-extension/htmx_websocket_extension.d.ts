/* tslint:disable */
/* eslint-disable */
export class WebSocketExtensionModule {
  free(): void;
  constructor();
  register_with_core(core: any): void;
  create_connection(url: string, element: Element): void;
  send_message(url: string, message: string): void;
  close_connection(url: string): void;
  get_connection_state(url: string): number;
}

export type InitInput = RequestInfo | URL | Response | BufferSource | WebAssembly.Module;

export interface InitOutput {
  readonly memory: WebAssembly.Memory;
  readonly __wbg_websocketextensionmodule_free: (a: number, b: number) => void;
  readonly websocketextensionmodule_new: () => number;
  readonly websocketextensionmodule_register_with_core: (a: number, b: any) => [number, number];
  readonly websocketextensionmodule_create_connection: (a: number, b: number, c: number, d: any) => [number, number];
  readonly websocketextensionmodule_send_message: (a: number, b: number, c: number, d: number, e: number) => [number, number];
  readonly websocketextensionmodule_close_connection: (a: number, b: number, c: number) => [number, number];
  readonly websocketextensionmodule_get_connection_state: (a: number, b: number, c: number) => number;
  readonly __wbindgen_exn_store: (a: number) => void;
  readonly __externref_table_alloc: () => number;
  readonly __wbindgen_export_2: WebAssembly.Table;
  readonly __wbindgen_free: (a: number, b: number, c: number) => void;
  readonly __wbindgen_malloc: (a: number, b: number) => number;
  readonly __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
  readonly __wbindgen_export_6: WebAssembly.Table;
  readonly __externref_table_dealloc: (a: number) => void;
  readonly closure12_externref_shim: (a: number, b: number, c: any) => void;
  readonly __wbindgen_start: () => void;
}

export type SyncInitInput = BufferSource | WebAssembly.Module;
/**
* Instantiates the given `module`, which can either be bytes or
* a precompiled `WebAssembly.Module`.
*
* @param {{ module: SyncInitInput }} module - Passing `SyncInitInput` directly is deprecated.
*
* @returns {InitOutput}
*/
export function initSync(module: { module: SyncInitInput } | SyncInitInput): InitOutput;

/**
* If `module_or_path` is {RequestInfo} or {URL}, makes a request and
* for everything else, calls `WebAssembly.instantiate` directly.
*
* @param {{ module_or_path: InitInput | Promise<InitInput> }} module_or_path - Passing `InitInput` directly is deprecated.
*
* @returns {Promise<InitOutput>}
*/
export default function __wbg_init (module_or_path?: { module_or_path: InitInput | Promise<InitInput> } | InitInput | Promise<InitInput>): Promise<InitOutput>;
