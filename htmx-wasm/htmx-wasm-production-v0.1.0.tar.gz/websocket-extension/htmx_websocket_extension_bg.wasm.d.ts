/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export const __wbg_websocketextensionmodule_free: (a: number, b: number) => void;
export const websocketextensionmodule_new: () => number;
export const websocketextensionmodule_register_with_core: (a: number, b: any) => [number, number];
export const websocketextensionmodule_create_connection: (a: number, b: number, c: number, d: any) => [number, number];
export const websocketextensionmodule_send_message: (a: number, b: number, c: number, d: number, e: number) => [number, number];
export const websocketextensionmodule_close_connection: (a: number, b: number, c: number) => [number, number];
export const websocketextensionmodule_get_connection_state: (a: number, b: number, c: number) => number;
export const __wbindgen_exn_store: (a: number) => void;
export const __externref_table_alloc: () => number;
export const __wbindgen_export_2: WebAssembly.Table;
export const __wbindgen_free: (a: number, b: number, c: number) => void;
export const __wbindgen_malloc: (a: number, b: number) => number;
export const __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
export const __wbindgen_export_6: WebAssembly.Table;
export const __externref_table_dealloc: (a: number) => void;
export const closure12_externref_shim: (a: number, b: number, c: any) => void;
export const __wbindgen_start: () => void;
