/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export const __wbg_htmxcore_free: (a: number, b: number) => void;
export const htmxcore_new: () => number;
export const htmxcore_processElement: (a: number, b: number, c: number) => void;
export const main: () => void;
export const __wbindgen_export_0: (a: number, b: number) => number;
export const __wbindgen_export_1: (a: number, b: number, c: number, d: number) => number;
export const __wbindgen_add_to_stack_pointer: (a: number) => number;
export const __wbindgen_start: () => void;
