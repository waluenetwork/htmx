/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export const __wbg_htmxultraminimal_free: (a: number, b: number) => void;
export const htmxultraminimal_new: () => number;
export const htmxultraminimal_process_element: (a: number, b: number, c: number) => void;
export const htmxultraminimal_get_version: (a: number, b: number) => void;
export const __wbindgen_export_0: (a: number, b: number) => number;
export const __wbindgen_export_1: (a: number, b: number, c: number, d: number) => number;
export const __wbindgen_add_to_stack_pointer: (a: number) => number;
export const __wbindgen_export_2: (a: number, b: number, c: number) => void;
