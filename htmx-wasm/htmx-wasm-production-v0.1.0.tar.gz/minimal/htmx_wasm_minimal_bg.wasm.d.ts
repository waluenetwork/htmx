/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export const __wbg_htmxminimal_free: (a: number, b: number) => void;
export const htmxminimal_new: () => number;
export const htmxminimal_is_initialized: (a: number) => number;
export const htmxminimal_process_element: (a: number, b: number, c: number) => void;
export const htmxminimal_get_version: (a: number, b: number) => void;
export const __wbindgen_export_0: (a: number, b: number, c: number) => void;
export const __wbindgen_export_1: (a: number, b: number) => number;
export const __wbindgen_export_2: (a: number, b: number, c: number, d: number) => number;
export const __wbindgen_add_to_stack_pointer: (a: number) => number;
